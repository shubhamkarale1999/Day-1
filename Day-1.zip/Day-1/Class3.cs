﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_1
{
    public class Program3
    {
        public static void Exicute()
        {
            Console.WriteLine("Enter First Number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter First Number");
            int num2=int.Parse(Console.ReadLine());
            
            {
                Console.WriteLine();
            }


        }
    }
}
