﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_1
{
    public class Class2
    {
        public static void Execute()
        {


            Console.WriteLine("Please Enter First Number");
            int num= int.Parse(Console.ReadLine());
         
            if(num>51)
            {
                Console.WriteLine(3 * (num - 51));
            }
            else
            {
                Console.WriteLine(51-num);
            }
            Console.ReadLine();

        }
    }
}
