﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //-------1) Swap Two Variables Without using Third Variable-------
            /* int num1 = 5;
             int num2 = 6;
             Console.WriteLine("After swapping num1 : {0} and num2 : {1}", num1,num2);
             num1 = num2+num1;//11
             num2= num1 - num2;//11-6=5
             num1 = num1 - num2;//5+
             Console.WriteLine("\nBefore swaping num1 : {0} and num2 : {1}",num1, num2);
             Console.ReadLine();*/

            //-------2) Multiplication-----------

            /*  Console.WriteLine("Please Enter a first Number");
              int num1=int.Parse(Console.ReadLine());
              Console.WriteLine("Please Enter a Second Number");
              int num2 = int.Parse(Console.ReadLine());
              Console.WriteLine("Please Enter a first Number");
              int num3=int.Parse(Console.ReadLine());
              Console.Write("Multiplication of Above Threee Numbers is\n{0}*{1}*{2}=",num1,num2,num3,+(num1*num2*num3));
              Console.Write(num1 * num2 * num3);
              Console.ReadLine();*/

            //-----------3)Addition of Two Progaram----------

            /*   Console.WriteLine("Please Enter a first Number");
               int num1=int.Parse(Console.ReadLine());
               Console.WriteLine("Please Enter a Second Number");
               int num2=int.Parse(Console.ReadLine());
               Console.WriteLine("Addition of Two Numbers");
               Console.WriteLine("Addition = "+(num1 + num2));
               Console.WriteLine("Substraction of Two Numbers");
               Console.WriteLine("Subtrction =" + (num1 - num2));
               Console.WriteLine("Multiplication of Two Numbers");
               Console.WriteLine("Multiplication ="+(num1*num2));
               Console.WriteLine("Division of Two Numbers");
               Console.WriteLine("Division = "+(num1/num2));
               Console.ReadLine();*/

            //-----------4)Multiplication Table---------

            /* Console.WriteLine("Please Entere a Number");
             int num=int.Parse(Console.ReadLine());
             for(int i=1; i<=10; i++)
             {
                 Console.WriteLine(num+" * "+i+" = "+(i*num));

             }
             Console.ReadLine();*/

            //--------------5)Average of Four Numbers-----------

            /*  Console.WriteLine("Please Enter First Number");
              int num1 = int.Parse(Console.ReadLine());
              Console.WriteLine("Please Enter Second Number");
              int num2 = int.Parse(Console.ReadLine());
              Console.WriteLine("Please Enter Third Number");
              int num3 = int.Parse(Console.ReadLine());
              Console.WriteLine("Please Enter Fourth Number");
             int num4=int.Parse(Console.ReadLine());
              Console.WriteLine("Average of Above Four Numbers");
              Console.WriteLine(num1 + "+"+ num2 + "+" + num3 + "+" + num4 + "="+(num1+num2+num3+num4)/4);
              Console.ReadLine();*/

            //--------------6)Number in Row With Space and Without Space----------------

               Console.WriteLine("Please Enetr A Number");
               int num=int.Parse(Console.ReadLine());
               string massage = "num";
               Console.WriteLine("{0}{0}{0}{0}",num);
               Console.WriteLine("{0} {0} {0} {0}",num);
               Console.WriteLine("{0}{0}{0}{0}",num);
               Console.WriteLine("{0} {0} {0} {0}",num);
               Console.ReadLine();

            //---------------7)Pattern-----------------------------

            /*  Console.WriteLine("Please Enter A Number");
              int num1=int.Parse(Console.ReadLine());
              string num = "5";
              for (int i = 0; i <= 4; i++)
              {
                  for (int j = 0; j <= 4; j++)
                  {
                      if (i == 0 || i == 4)
                      {
                          Console.Write(num + " ");
                      }
                      else if (j == 4 || j == 0)
                      {
                          Console.Write(num + " ");
                      }

                      else
                      {
                          Console.Write("  ");
                      }
                  }
                  Console.WriteLine();
              }
              Console.ReadLine();

              //-----------------8)Covert celsias To Faranheight---------------

              /*   Console.Write("Please Enter The Temperature in Number ");
                 int c= int.Parse(Console.ReadLine());
                 double Kelvin = c + 273;
                 Console.WriteLine("Kelvin = {0}", Kelvin) ;
                 double F = c * 18 / 10 + 32;
                 Console.WriteLine("Fahrenheit = {0}",F );*/

            //-----------------9)Check if Number is Positive or Negative------------
            /*
              Console.WriteLine("Please Enetr First Number");
               int num1=int.Parse(Console.ReadLine());
               Console.WriteLine("Please Enetr Second Number");
               int num2=int.Parse(Console.ReadLine());
               if(num1<0 && num2>0)
               {
                   Console.WriteLine("True");
               }
                 else if(num1>0&& num2>0)
                  { 
                  Console.WriteLine("True");
                  }
               else
               {
                   Console.WriteLine("False");
               }
               Console.ReadLine();*/

            //-----------------10)Diffrrancr Between Two Numbers-------------
            /*

            Console.WriteLine("Please Enetr First Number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Please Enetr Second Number");
            int num2=int.Parse(Console.ReadLine());
            double num3 = num1 - num2;
            Console.WriteLine("Differance " + num3);

            */
            //----------11)Pattern--------------

            /*    Console.Write("Please Enetr A number ");
                int num = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("{0} {0} {0} {0}", num);
                Console.WriteLine("{0}     {0}", num);
                Console.WriteLine("{0}     {0}", num);
                Console.WriteLine("{0}     {0}", num);
                Console.WriteLine("{0} {0} {0} {0}", num);
                Console.ReadLine();*/
            // Class1 c = new Class1();
            // Class1.Execute();
          //  Class2.Execute();
        }

        
        
      
    }
}
