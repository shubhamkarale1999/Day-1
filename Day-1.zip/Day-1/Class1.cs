﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_1
{
    public class Class1
    {
        public static void Execute()
        {
            Console.WriteLine("Please Enter First Number");
            int num1 =int.Parse( Console.ReadLine());
            Console.WriteLine("Please Enter Second Number");
            int num2=int.Parse( Console.ReadLine());
            if(num1 == num2)
            {
                Console.WriteLine(3 * (num1 + num2));
            }
            else
            {
                Console.WriteLine((num1 + num2));
            }
            Console.ReadLine(); 

        }
    }
}
